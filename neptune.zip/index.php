<?php get_header(); ?>

    <?php include_once locate_template('/components/blog.php'); ?>

<?php get_footer(); ?>
