<section class="partners">
    <div class="container">

    <h2>Ils nous font confiance</h2>

        <div class="partners_grid">
            <div>
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/src/images/logo-neptune.png" alt="Logo Neptune.">
            </div>
            <div>
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/src/images/logo-neptune.png" alt="Logo Neptune.">
            </div>
            <div>
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/src/images/logo-neptune.png" alt="Logo Neptune.">
            </div>
            <div>
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/src/images/logo-neptune.png" alt="Logo Neptune.">
            </div>
            <div>
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/src/images/logo-neptune.png" alt="Logo Neptune.">
            </div>
            <div>
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/src/images/logo-neptune.png" alt="Logo Neptune.">
            </div>
            <div>
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/src/images/logo-neptune.png" alt="Logo Neptune.">
            </div>
            <div>
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/src/images/logo-neptune.png" alt="Logo Neptune.">
            </div>
        </div>

    </div>
</section>