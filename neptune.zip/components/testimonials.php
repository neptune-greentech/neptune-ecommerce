<section class="testimonial">
    <div class="max-container">
        <div class="container">
            <div class="grid">
                <div class="column column--12">
                    <h2>Avis clients</h2>
                </div>
            </div>
            <div class="grid">
                <div class="column column--12">

                    <div class="testimonials">
                        <div class="prev">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/src/images/icon-arrow-left.png" alt="Icon arrow left.">
                        </div>
                        <div class="next">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/src/images/icon-arrow-right.png" alt="Icon arrow right.">
                        </div>
                        <div>
                            <div class="bloc">
                                <div class="slider">
                                    <div class="slider_inner">
                                        
                                        <div class="slide">
                                            <h3>Marie Doe</h3>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
                                        </div>

                                        <div class="slide">
                                            <h3>John Doe</h3>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
                                        </div>

                                        <div class="slide">
                                            <h3>Marie Doe</h3>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>