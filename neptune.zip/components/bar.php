<?php if(get_theme_mod('neptune_bar')) :?>
    <a class="bar" href="<?php echo esc_url(get_theme_mod('neptune_bar_link')); ?>" title="Neptune GreenTech website">
        <?php echo get_theme_mod('neptune_bar'); ?>
    </a>
<?php endif; ?>