<?php

include_once locate_template('/config/clean/api.php');
include_once locate_template('/config/clean/embed.php');
include_once locate_template('/config/clean/emoji.php');
include_once locate_template('/config/clean/gutenberg.php');
include_once locate_template('/config/clean/head.php');